#include "MainWindow.h"
#include "ui_MainWindow.h"
#include "ui_gamewindow.h"// The UI header for the second window

#include <string>
#include <QString>
#include <unordered_map>
#include <functional>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
    ui(new Ui::MainWindow)  // Initialize the MainWindow UI
{
    ui->setupUi(this);  // Set up MainWindow UI
}

MainWindow::~MainWindow()
{
    delete ui;  // Clean up the MainWindow UI pointer
}

void MainWindow::on_pushButton_released()
{
    // Show the GameWindow plainTextEdit_1
    QString name1=ui->plainTextEdit_1->toPlainText();
    QString name2=ui->plainTextEdit_2->toPlainText();
    // qDebug()<<"name1: "<<name1<<"name2: "<<name2;
    // if(name1=="" && name2==""){
    //     gamewindow* game = new gamewindow;  // Create an instance of gamewindow
    //     game->show();}
    // else{
        gamewindow* game = new gamewindow(name1,name2);
        // game->board_pushers[&(game->Board1)];
        game->show();



  // Show the GameWindow
    this->hide();  // Optionally close MainWindow when GameWindow is shown
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

gamewindow::gamewindow(QString& name1,QString& name2,QWidget *parent)
    : QMainWindow(parent),ui(new Ui::gamewindow) ,Player_1(name1),Player_2(name2)
     // Initialize the gamewindow UI with 2 input names.
{
    ui->setupUi(this);  // Set up the GameWindow UI
    // //qDebug()<<"constructor called.";
    //qDebug() << "PushButton_1: " << ui->PushButton_1;

    ui->label_Player1->setText(name1);
    ui->label_Player2->setText(name2);
    switcher();
    initialStates={ {ui->PushButton_1,saveInitialState(ui->PushButton_1)},
                    {ui->PushButton_2,saveInitialState(ui->PushButton_2)},
                    {ui->PushButton_3,saveInitialState(ui->PushButton_3)},
                    {ui->PushButton_4,saveInitialState(ui->PushButton_4)},
                    {ui->PushButton_5,saveInitialState(ui->PushButton_5)},
                    {ui->PushButton_6,saveInitialState(ui->PushButton_6)},
                    {ui->PushButton_7,saveInitialState(ui->PushButton_7)},
                    {ui->PushButton_8,saveInitialState(ui->PushButton_8)},
                    {ui->PushButton_9,saveInitialState(ui->PushButton_9)}};

    Pushers={ {0,ui->PushButton_1},{1,ui->PushButton_2},{2,ui->PushButton_3},{3,ui->PushButton_4},{4,ui->PushButton_5},{5,ui->PushButton_6},{6,ui->PushButton_7},{7,ui->PushButton_8},{8,ui->PushButton_9}
    };
    for(auto& s:Pushers){s.second->setFixedSize(62,59);}
    //qDebug()<<"Pushers[1]: "<<Pushers[1];
    // editor_buttons={
    //     {1, [this]() { on_PushButton_1_clicked(); }},
    //     {2, [this]() { on_PushButton_2_clicked(); }},
    //     {3, [this]() { on_PushButton_3_clicked(); }},
    //     {4, [this]() { on_PushButton_4_clicked(); }},
    //     {5, [this]() { on_PushButton_5_clicked(); }},
    //     {6, [this]() { on_PushButton_6_clicked(); }},
    //     {7, [this]() { on_PushButton_7_clicked(); }},
    //     {8, [this]() { on_PushButton_8_clicked(); }},
    //     {9, [this]() { on_PushButton_9_clicked(); }}
    //};
    Main_Labels={   {11,ui->Main_label11},{12,ui->Main_label12},{13,ui->Main_label13},{14,ui->Main_label14},{15,ui->Main_label15},{16,ui->Main_label16},{17,ui->Main_label17},{18,ui->Main_label18},{19,ui->Main_label19},
                    {21,ui->Main_label21},{22,ui->Main_label22},{23,ui->Main_label23},{24,ui->Main_label24},{25,ui->Main_label25},{26,ui->Main_label26},{27,ui->Main_label27},{28,ui->Main_label28},{29,ui->Main_label29},
                    {31,ui->Main_label31},{32,ui->Main_label32},{33,ui->Main_label33},{34,ui->Main_label34},{35,ui->Main_label35},{36,ui->Main_label36},{37,ui->Main_label37},{38,ui->Main_label38},{39,ui->Main_label39},
                    {41,ui->Main_label41},{42,ui->Main_label42},{43,ui->Main_label43},{44,ui->Main_label44},{45,ui->Main_label45},{46,ui->Main_label46},{47,ui->Main_label47},{48,ui->Main_label48},{49,ui->Main_label49},
                    {51,ui->Main_label51},{52,ui->Main_label52},{53,ui->Main_label53},{54,ui->Main_label54},{55,ui->Main_label55},{56,ui->Main_label56},{57,ui->Main_label57},{58,ui->Main_label58},{59,ui->Main_label59},
                    {61,ui->Main_label61},{62,ui->Main_label62},{63,ui->Main_label63},{64,ui->Main_label64},{65,ui->Main_label65},{66,ui->Main_label66},{67,ui->Main_label67},{68,ui->Main_label68},{69,ui->Main_label69},
                    {71,ui->Main_label71},{72,ui->Main_label72},{73,ui->Main_label73},{74,ui->Main_label74},{75,ui->Main_label75},{76,ui->Main_label76},{77,ui->Main_label77},{78,ui->Main_label78},{79,ui->Main_label79},
                    {81,ui->Main_label81},{82,ui->Main_label82},{83,ui->Main_label83},{84,ui->Main_label84},{85,ui->Main_label85},{86,ui->Main_label86},{87,ui->Main_label87},{88,ui->Main_label88},{89,ui->Main_label89},
                    {91,ui->Main_label91},{92,ui->Main_label92},{93,ui->Main_label93},{94,ui->Main_label94},{95,ui->Main_label95},{96,ui->Main_label96},{97,ui->Main_label97},{98,ui->Main_label98},{99,ui->Main_label99}

    };
    Available_Pushers={{1,ui->Board1},{2,ui->Board2},{3,ui->Board3},{4,ui->Board4},{5,ui->Board5},{6,ui->Board6},{7,ui->Board7},{8,ui->Board8},{9,ui->Board9},
                        {10,ui->board1},{11,ui->board2},{12,ui->board3},{13,ui->board4},{14,ui->board5},{15,ui->board6},{16,ui->board7},{17,ui->board8},{18,ui->board9}
};
}

gamewindow::~gamewindow()
{
    delete ui;  // Clean up the GameWindow UI pointer
}
void gamewindow::inactive_board(){
    for(int i=0; i<9; ++i){
        Pushers[i]->setAttribute(Qt::WA_TransparentForMouseEvents, true);
    }

}

ButtonState gamewindow::saveInitialState(QPushButton *button)

{
    ButtonState state;
    state.text = button->text();
    // state.checked = button->isChecked();
    // state.style = button->styleSheet();
    state.icon = button->icon();
    return state;
    // Store the initial state of the button in the map

}
void gamewindow::resetButtonToInitialState(QPushButton *button)
{
    if (initialStates.contains(button)) {
        ButtonState state = initialStates[button];
        button->setText(state.text);
        // button->setChecked(state.checked);
        // button->setStyleSheet(state.style);
        button->setIcon(state.icon);
        button->setAttribute(Qt::WA_TransparentForMouseEvents, false);
    }}
    /* else if (button==nullptr){
        qDebug() << "No initial state found for button: "<<button;
    }else{qDebug()<<"neither nullptr nor a button";
    }}*/

void gamewindow::on_pushButton_released()//back button on game window
{
    MainWindow* main =new MainWindow;
    main->show();
    this->close();
    // Disconnect the clicked() signal of the button from any unintended slot
    // disconnect(ui->pushButton, SIGNAL(clicked()), nullptr, nullptr);

}

void gamewindow::switcher(){
(curr_chance == cross) ? (ui->Player1_choices->setEnabled(true), ui->Player1_choices->setVisible(true), ui->Player2_choices->setEnabled(false), ui->Player2_choices->setVisible(false))
                         : (ui->Player1_choices->setEnabled(false), ui->Player1_choices->setVisible(false), ui->Player2_choices->setEnabled(true), ui->Player2_choices->setVisible(true));

}
void gamewindow::Board_Switcher(vector<QString> *source){
    if((*source)[10]==none){
        for(auto& i:Available_Pushers){
            i.second->setEnabled(false);
        }
        int curr=(*curr_board)[9].toInt();
        Available_Pushers[curr]->setEnabled(true);
        Available_Pushers[curr+9]->setEnabled(true);

    }else{
        for(auto& i:Available_Pushers){
            i.second->setEnabled(true);
        }

        }
    }


void gamewindow::Main_Board_Displayer(int n){
    QString i = (*curr_board)[9];
    int num= i.toInt();
    QPixmap pixmap(":/new/prefix1/"+curr_chance+"-sign.jpg");// Load the image from the resources
    Main_Labels[num*10+n]->setFixedSize(44,33);
    Main_Labels[num*10+n]->setPixmap(pixmap);  // Set the pixmap to the QLabel
    Main_Labels[num*10+n]->setScaledContents(true);
}
void gamewindow::available_grid_winners(){
    int num=(*curr_board)[9].toInt();
    Available_Pushers[num]->setStyleSheet("font-weight: bold; font-size: 40px; border:1px solid black; background-color:rgb(255, 0, 0);");
    Available_Pushers[num]->setText((*curr_board)[10]==cross?"X":"O");
    Available_Pushers[num+9]->setStyleSheet("font-weight: bold; font-size:40px; border:1px solid black; background-color:rgb(255, 0, 0);");
    Available_Pushers[num+9]->setText((*curr_board)[10]==cross?"X":"O");
}
void gamewindow::winner_func(){
    bool game_over=false;
    if(Board1[10]!=none && Board2[10]==Board1[10] && Board2[10]==Board3[10]){
        winner=Board1[10];
        game_over=true;
    }
    else if(Board4[10]!=none && Board4[10]==Board5[10] && Board5[10]==Board6[10]){
        winner=Board4[10];
        game_over=true;
    }
    else if(Board7[10]!=none && Board7[10]==Board8[10] && Board8[10]==Board9[10]){
        winner=Board7[10];
        game_over=true;
    }
    else if(Board1[10]!=none && Board1[10]==Board4[10] && Board4[10]==Board7[10]){
        winner=Board1[10];
        game_over=true;
    }
    else if(Board2[10]!=none && Board2[10]==Board5[10] && Board5[10]==Board8[10]){
        winner=Board2[10];
        game_over=true;
    }
    else if(Board3[10]!=none && Board3[10]==Board6[10] && Board6[10]==Board9[10]){
        winner=Board3[10];
        game_over=true;
    }
    else if(Board1[10]!=none && Board1[10]==Board5[10] && Board5[10]==Board9[10]){
        winner=Board1[10];
        game_over=true;
    }
    else if(Board3[10]!=none && Board3[10]==Board5[10] && Board5[10]==Board7[10]){
        winner=Board3[10];
        game_over=true;
    }
    if(game_over==true){
        ui->Main_board_widget->setVisible(false);
        QString Player_winner=(winner==cross)?Player_1:Player_2;
        ui->winner_label->setText("<div align='center'><font size='100'  color='blue'>"+ Player_winner+ "<br>Wins!</font>");
    }
    }
void gamewindow::winner_checker_miniboards(){
    if((*curr_board)[0]!=empty && (*curr_board)[1]==(*curr_board)[0] && (*curr_board)[2]==(*curr_board)[1]){
        ((*curr_board))[10]=(*curr_board)[0];
        inactive_board();
        available_grid_winners();
        winner_func();
        }
    else if((*curr_board)[3]!=empty && (*curr_board)[3]==(*curr_board)[4] && (*curr_board)[4]==(*curr_board)[5]){
        ((*curr_board))[10]=(*curr_board)[3];
        inactive_board();
        available_grid_winners();
        winner_func();
        }
    else if((*curr_board)[6]!=empty && (*curr_board)[6]==(*curr_board)[7] && (*curr_board)[7]==(*curr_board)[8]){
        ((*curr_board))[10]=(*curr_board)[6];
        inactive_board();
        available_grid_winners();
        winner_func();
        }
    else if((*curr_board)[0]!=empty && (*curr_board)[0]==(*curr_board)[3] && (*curr_board)[3]==(*curr_board)[6]){
        ((*curr_board))[10]=(*curr_board)[0];
        inactive_board();
        available_grid_winners();
        winner_func();
        }
    else if((*curr_board)[1]!=empty && (*curr_board)[1]==(*curr_board)[4] && (*curr_board)[4]==(*curr_board)[7]){
        ((*curr_board))[10]=(*curr_board)[1];
        inactive_board();
        available_grid_winners();
        winner_func();
        }
    else if((*curr_board)[2]!=empty && (*curr_board)[2]==(*curr_board)[5] && (*curr_board)[5]==(*curr_board)[8]){
        ((*curr_board))[10]=(*curr_board)[2];
        inactive_board();
        available_grid_winners();
        winner_func();
        }
    else if((*curr_board)[0]!=empty && (*curr_board)[0]==(*curr_board)[4] && (*curr_board)[4]==(*curr_board)[8]){
        ((*curr_board))[10]=(*curr_board)[0];
        inactive_board();
        available_grid_winners();
        winner_func();
        }
    else if((*curr_board)[2]!=empty && (*curr_board)[2]==(*curr_board)[4] && (*curr_board)[4]==(*curr_board)[6]){
        ((*curr_board))[10]=(*curr_board)[2];
        inactive_board();
        available_grid_winners();
        winner_func();
        }

}
/////////////////////////////////////////////////
void gamewindow::on_PushButton_1_clicked(){

    QIcon buttonIcon(":/new/prefix1/"+curr_chance+"-sign.jpg");  // Path to your image or resource
    // ui->PushButton_1->setStyleSheet("QPushButton {"
    //                                 "border-top: none; "     /* No top border */
    //                                 "border-left: none;"     /* No left border */
    //                                 "border-right: 1px solid black;" /* Black right border */
    //                                " border-bottom: 1px solid black;"/* Black bottom border */
    //                                 "}");
    Main_Board_Displayer(1);
    ui->PushButton_1->setText("");
    ui->PushButton_1->setAttribute(Qt::WA_TransparentForMouseEvents, true);//find way for changing this as reqd. when changing the board.
    ui->PushButton_1->setIcon(buttonIcon);

    ((*curr_board))[0]=curr_chance;
    winner_checker_miniboards();
    curr_chance=((circle==curr_chance)?cross:circle);
    switcher();
    on_Board1_clicked();
    Board_Switcher(curr_board);

}

void gamewindow::on_PushButton_2_clicked(){
    QIcon buttonIcon(":/new/prefix1/"+curr_chance+"-sign.jpg");  // Path to your image or resource
    Main_Board_Displayer(2);
    ui->PushButton_2->setText("");
    ui->PushButton_2->setAttribute(Qt::WA_TransparentForMouseEvents, true);
    ui->PushButton_2->setIcon(buttonIcon);
    (*curr_board)[1]=curr_chance;
    winner_checker_miniboards();
    curr_chance=((circle==curr_chance)?cross:circle);
    switcher();
    on_Board2_clicked();
    Board_Switcher(curr_board);
    }

void gamewindow::on_PushButton_3_clicked(){
    QIcon buttonIcon(":/new/prefix1/"+curr_chance+"-sign.jpg");  // Path to your image or resource
    Main_Board_Displayer(3);
    ui->PushButton_3->setText("");
    ui->PushButton_3->setAttribute(Qt::WA_TransparentForMouseEvents, true);
    ui->PushButton_3->setIcon(buttonIcon);
    (*curr_board)[2]=curr_chance;
    winner_checker_miniboards();
    curr_chance=((circle==curr_chance)?cross:circle);
    switcher();
    on_Board3_clicked();
    Board_Switcher(curr_board);
    }
void gamewindow::on_PushButton_4_clicked(){
    QIcon buttonIcon(":/new/prefix1/"+curr_chance+"-sign.jpg");  // Path to your image or resource
    Main_Board_Displayer(4);
    ui->PushButton_4->setText("");
    ui->PushButton_4->setAttribute(Qt::WA_TransparentForMouseEvents, true);
    ui->PushButton_4->setIcon(buttonIcon);
    (*curr_board)[3]=curr_chance;
    winner_checker_miniboards();
    curr_chance=((circle==curr_chance)?cross:circle);
    switcher();
    on_Board4_clicked();
    Board_Switcher(curr_board);
    }
void gamewindow::on_PushButton_5_clicked(){
    QIcon buttonIcon(":/new/prefix1/"+curr_chance+"-sign.jpg");  // Path to your image or resource
    Main_Board_Displayer(5);
    ui->PushButton_5->setText("");
    ui->PushButton_5->setAttribute(Qt::WA_TransparentForMouseEvents, true);
    ui->PushButton_5->setIcon(buttonIcon);
    (*curr_board)[4]=curr_chance;
    winner_checker_miniboards();
    curr_chance=((circle==curr_chance)?cross:circle);
    switcher();
    on_Board5_clicked();
    Board_Switcher(curr_board);
    }
void gamewindow::on_PushButton_6_clicked(){
    QIcon buttonIcon(":/new/prefix1/"+curr_chance+"-sign.jpg");  // Path to your image or resource
    Main_Board_Displayer(6);
    ui->PushButton_6->setText("");
    ui->PushButton_6->setAttribute(Qt::WA_TransparentForMouseEvents, true);
    ui->PushButton_6->setIcon(buttonIcon);
    (*curr_board)[5]=curr_chance;
    winner_checker_miniboards();
    curr_chance=((circle==curr_chance)?cross:circle);
    switcher();
    on_Board6_clicked();
    Board_Switcher(curr_board);
    }
void gamewindow::on_PushButton_7_clicked(){
    QIcon buttonIcon(":/new/prefix1/"+curr_chance+"-sign.jpg");  // Path to your image or resource
    Main_Board_Displayer(7);
    ui->PushButton_7->setText("");
    ui->PushButton_7->setAttribute(Qt::WA_TransparentForMouseEvents, true);
    ui->PushButton_7->setIcon(buttonIcon);
    (*curr_board)[6]=curr_chance;
    winner_checker_miniboards();
    curr_chance=((circle==curr_chance)?cross:circle);
    switcher();
    on_Board7_clicked();
    Board_Switcher(curr_board);
    }
void gamewindow::on_PushButton_8_clicked(){
    QIcon buttonIcon(":/new/prefix1/"+curr_chance+"-sign.jpg");  // Path to your image or resource
    Main_Board_Displayer(8);
    ui->PushButton_8->setText("");
    ui->PushButton_8->setAttribute(Qt::WA_TransparentForMouseEvents, true);
    ui->PushButton_8->setIcon(buttonIcon);
    (*curr_board)[7]=curr_chance;
    // qDebug()<<curr_board[8];
    winner_checker_miniboards();
    curr_chance=((circle==curr_chance)?cross:circle);
    switcher();
    on_Board8_clicked();
    Board_Switcher(curr_board);
    }
void gamewindow::on_PushButton_9_clicked(){/*Correct this BASTARD!*/
    QIcon buttonIcon(":/new/prefix1/"+curr_chance+"-sign.jpg");  // Path to your image or resource
    Main_Board_Displayer(9);
    ui->PushButton_9->setText("");
    ui->PushButton_9->setAttribute(Qt::WA_TransparentForMouseEvents, true);
    ui->PushButton_9->setIcon(buttonIcon);
    (*curr_board)[8]=curr_chance;
    winner_checker_miniboards();
    curr_chance=((circle==curr_chance)?cross:circle);
    switcher();
    on_Board9_clicked();
    Board_Switcher(curr_board);
    }
//////////////////////////////////////////////////////////////////



void gamewindow::on_Board1_clicked()
{if(Board1[10]==none){
        for(int s=0; s<9; ++s){if(Board1[s]==empty){
            resetButtonToInitialState(Pushers[s]);
        }else{

            QIcon buttonIcon(":/new/prefix1/"+Board1[s]+"-sign.jpg");  // Path to your image or resource
            // Pushers[s]->setStyleSheet("QPushButton {"
            //                                 "border-top: 1px solid black; "     /* No top border */
            //                                 "border-left: 1px solid black;"     /* No left border */
            //                                 "border-right:  1px solid black;" /* Black right border */
            //                                 " border-bottom: none;" /* Black bottom border */
            //                                 "}");
            Pushers[s]->setText("");
            Pushers[s]->setAttribute(Qt::WA_TransparentForMouseEvents, true);
            Pushers[s]->setIcon(buttonIcon);
        }
    }
    // qDebug()<<"Board1 call finished!";
    curr_board=&Board1;
    }else{
        for(int s=0; s<9; ++s){if(Board1[s]==empty){
                resetButtonToInitialState(Pushers[s]);
                Pushers[s]->setAttribute(Qt::WA_TransparentForMouseEvents, true);
            }else{
                QIcon buttonIcon(":/new/prefix1/"+Board1[s]+"-sign.jpg");  // Path to your image or resource
                // Pushers[s]->setStyleSheet("QPushButton {"
                //                                 "border-top: 1px solid black; "     /* No top border */
                //                                 "border-left: 1px solid black;"     /* No left border */
                //                                 "border-right:  1px solid black;" /* Black right border */
                //                                 " border-bottom: none;" /* Black bottom border */
                //                                 "}");
                Pushers[s]->setText("");
                Pushers[s]->setAttribute(Qt::WA_TransparentForMouseEvents, true);
                Pushers[s]->setIcon(buttonIcon);
            }}}}


void gamewindow::on_Board2_clicked()
{
    for(int s=0; s<9; ++s){if(Board2[s]==empty){/*qDebug()<<"Pushers["<<s<<"]: "<<"set to empty";*/
            resetButtonToInitialState(Pushers[s]);
        }else{    QIcon buttonIcon(":/new/prefix1/"+Board2[s]+"-sign.jpg");  // Path to your image or resource
            Pushers[s]->setText("");
            Pushers[s]->setAttribute(Qt::WA_TransparentForMouseEvents, true);
            Pushers[s]->setIcon(buttonIcon);
        }
    }
    // qDebug()<<"Board2 call finished!";
    curr_board=&Board2;
    if (Board2[10]!=none){
        inactive_board();
    }
   }


void gamewindow::on_Board3_clicked()
{
    for(int s=0; s<9; ++s){if(Board3[s]==empty){
            resetButtonToInitialState(Pushers[s]);
        }else{    QIcon buttonIcon(":/new/prefix1/"+Board3[s]+"-sign.jpg");  // Path to your image or resource
            Pushers[s]->setText("");
            Pushers[s]->setAttribute(Qt::WA_TransparentForMouseEvents, true);
            Pushers[s]->setIcon(buttonIcon);
        }
    }
    // qDebug()<<"Board3 call finished!";
    curr_board=&Board3;
    if(Board3[10]!=none){
        inactive_board();
    }
    }


void gamewindow::on_Board4_clicked()
    {
    for(int s=0; s<9; ++s){if(Board4[s]==empty){
            resetButtonToInitialState(Pushers[s]);
        }else{    QIcon buttonIcon(":/new/prefix1/"+Board4[s]+"-sign.jpg");  // Path to your image or resource
            Pushers[s]->setText("");
            Pushers[s]->setAttribute(Qt::WA_TransparentForMouseEvents, true);
            Pushers[s]->setIcon(buttonIcon);
        }
    }
    // qDebug()<<"Board4 call finished!";
    curr_board=&Board4;
    if(Board4[10]!=none){
        inactive_board();

    }}


void gamewindow::on_Board5_clicked()
        {
    for(int s=0; s<9; ++s){if(Board5[s]==empty){
            resetButtonToInitialState(Pushers[s]);
        }else{    QIcon buttonIcon(":/new/prefix1/"+Board5[s]+"-sign.jpg");  // Path to your image or resource
            Pushers[s]->setText("");
            Pushers[s]->setAttribute(Qt::WA_TransparentForMouseEvents, true);
            Pushers[s]->setIcon(buttonIcon);
        }
    }
    // qDebug()<<"Board5 call finished!";
    curr_board=&Board5;
    if(Board5[10]!=none){
        inactive_board();}
            }




void gamewindow::on_Board6_clicked()
            {
    for(int s=0; s<9; ++s){if(Board6[s]==empty){
            resetButtonToInitialState(Pushers[s]);
        }else{    QIcon buttonIcon(":/new/prefix1/"+Board6[s]+"-sign.jpg");  // Path to your image or resource
            Pushers[s]->setText("");
            Pushers[s]->setAttribute(Qt::WA_TransparentForMouseEvents, true);
            Pushers[s]->setIcon(buttonIcon);
        }
    }
    // qDebug()<<"Board6 call finished!";
    curr_board=&Board6;
    if(Board6[10]!=none){
        inactive_board();}
               }


void gamewindow::on_Board7_clicked()
            {
    for(int s=0; s<9; ++s){if(Board7[s]==empty){
            resetButtonToInitialState(Pushers[s]);
        }else{    QIcon buttonIcon(":/new/prefix1/"+Board7[s]+"-sign.jpg");  // Path to your image or resource
            Pushers[s]->setText("");
            Pushers[s]->setAttribute(Qt::WA_TransparentForMouseEvents, true);
            Pushers[s]->setIcon(buttonIcon);
        }
    }
    // qDebug()<<"Board7 call finished!";
    curr_board=&Board7;
    if(Board7[10]!=none){
        inactive_board();}}




void gamewindow::on_Board8_clicked()
            {
    for(int s=0; s<9; ++s){if(Board8[s]==empty){
            resetButtonToInitialState(Pushers[s]);
        }else{    QIcon buttonIcon(":/new/prefix1/"+Board8[s]+"-sign.jpg");  // Path to your image or resource
            Pushers[s]->setText("");
            Pushers[s]->setAttribute(Qt::WA_TransparentForMouseEvents, true);
            Pushers[s]->setIcon(buttonIcon);
        }
    }
    // qDebug()<<"Board8 call finished!";
    curr_board=&Board8;
    if(Board8[10]!=none){
        inactive_board();}
                }


void gamewindow::on_Board9_clicked()
            {
    for(int s=0; s<9; ++s){if(Board9[s]==empty){
            resetButtonToInitialState(Pushers[s]);
        }else{    QIcon buttonIcon(":/new/prefix1/"+Board9[s]+"-sign.jpg");  // Path to your image or resource
            Pushers[s]->setText("");
            Pushers[s]->setAttribute(Qt::WA_TransparentForMouseEvents, true);
            Pushers[s]->setIcon(buttonIcon);
        }
    }
    // qDebug()<<"Board9 call finished!";
    curr_board=&Board9;
    if(Board9[10]!=none){
        inactive_board();}
                }


void gamewindow::on_board1_clicked()
{
    on_Board1_clicked();
}



void gamewindow::on_board2_clicked()
{
    on_Board2_clicked();
}


void gamewindow::on_board3_clicked()
{
    on_Board3_clicked();
}


void gamewindow::on_board4_clicked()
{
    on_Board4_clicked();
}


void gamewindow::on_board5_clicked()
{
    on_Board5_clicked();
}


void gamewindow::on_board6_clicked()
{
    on_Board6_clicked();
}


void gamewindow::on_board7_clicked()
{
    on_Board7_clicked();
}


void gamewindow::on_board8_clicked()
{
    on_Board8_clicked();
}


void gamewindow::on_board9_clicked()
{
    on_Board9_clicked();
}


