#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ui_mainwindow.h"
#include "ui_gamewindow.h"// This UI will manage both main and game window setups
#include <vector>
#include <string>
#include <QString>
#include <unordered_map>
#include <functional>
using namespace std;

namespace Ui {
class MainWindow;
class gamewindow;
}

class MainWindow : public QMainWindow
{
        Q_OBJECT

    public:
        MainWindow(QWidget *parent = nullptr);
        ~MainWindow();

    private slots:
        void on_pushButton_released();  // Slot to show GameWindow, and hide mainwindow

    private:
        Ui::MainWindow *ui;
};
////////////////////////////////////////////////////////////////////////////////////////////////////////
struct ButtonState {
    QString text;
    bool checked;
    QString style;
    QIcon icon;
};
namespace std {
template<>
struct hash<QPushButton*> {
    size_t operator()(QPushButton* const& button) const noexcept {
        return reinterpret_cast<size_t>(button); // Hash by the pointer's address
    }
};
}
namespace std {
// Specialize std::hash for std::vector<QString>*
template <>
struct hash<std::vector<QString>*> {
    size_t operator()(std::vector<QString>* const& vecPtr) const noexcept {
        std::size_t hashValue = 0;
        // Hash each element of the vector pointed to by vecPtr
        for (const auto& elem : *vecPtr) {
            // Combine the hash of each QString element using XOR
            hashValue ^= std::hash<QString>{}(elem) + 0x9e3779b9 + (hashValue << 6) + (hashValue >> 2);
        }
        return hashValue;
    }
};
}

//functional class only for reading and declaring winners,maybe use the signals concept.
    //create widget object under each board in main_board and a label beneath.if a board has a winner,
    //the label gets its pixmap set accordingly and widget is setVisible(false).It also controls the current
    //available board which the user can select from Available_Boards_section. Its one object is to be
    //created which does all this along with the grand win thing,maybe make a winner declared window.


/////////////////////////////////////////////////////////////////////////////////////////////////////
class gamewindow : public QMainWindow {
        Q_OBJECT
    public:
        Ui::gamewindow *ui;
        // gamewindow(QWidget *parent = nullptr);
        gamewindow(QString& name1,QString& name2,QWidget *parent=nullptr);
        ~gamewindow();
        QString curr_chance="cross";
        QString cross= "cross";
        QString circle= "circle";
        void switcher();
        void Main_Board_Displayer(int n);
        void winner_checker_miniboards();
        void inactive_board();
        void winner_func();
//initializes a Main_board object with 2 players.
    public:
        QString Player_1="Player 1";
        QString Player_2= "Player 2";
        QString winner;
        QString empty="empty";
        QString none="none";
//Storage section for data of a gamewindow.BoardX[9] is board number.BoardX[10] is winner on BoardX.
        vector<QString> Board1={empty,empty,empty,empty,empty,empty,empty,empty,empty,"1",none};
        vector<QString> Board2={empty,empty,empty,empty,empty,empty,empty,empty,empty,"2",none};
        vector<QString> Board3={empty,empty,empty,empty,empty,empty,empty,empty,empty,"3",none};
        vector<QString> Board4={empty,empty,empty,empty,empty,empty,empty,empty,empty,"4",none};
        vector<QString> Board5={empty,empty,empty,empty,empty,empty,empty,empty,empty,"5",none};
        vector<QString> Board6={empty,empty,empty,empty,empty,empty,empty,empty,empty,"6",none};
        vector<QString> Board7={empty,empty,empty,empty,empty,empty,empty,empty,empty,"7",none};
        vector<QString> Board8={empty,empty,empty,empty,empty,empty,empty,empty,empty,"8",none};
        vector<QString> Board9={empty,empty,empty,empty,empty,empty,empty,empty,empty,"9",none};
        vector<QString>* curr_board=&Board5;//initializes with pointer to middle board B2.
//later maybe try to implement all changes wrt a vector<vector<QString>> Board_container; would reduce code
//by nearly 300 lines.


    public slots:
        void on_pushButton_released();//back button on gamewindow.
        ButtonState saveInitialState(QPushButton *button);//saves the initial state of the button
        void resetButtonToInitialState(QPushButton* button);//resets button to initial state
        void Board_Switcher(vector<QString>* source);//switches to available board,disables other (B/b)oardN(s).
        void available_grid_winners();
//Buttons for interaction of user with GridLayoutEditor.
        void on_PushButton_1_clicked();
        void on_PushButton_2_clicked();
        void on_PushButton_3_clicked();
        void on_PushButton_4_clicked();
        void on_PushButton_5_clicked();
        void on_PushButton_6_clicked();
        void on_PushButton_7_clicked();
        void on_PushButton_8_clicked();
        void on_PushButton_9_clicked();


    private slots:
//Buttons for user interaction with Available_Boards section on LEFT.
        void on_Board1_clicked();
        void on_Board2_clicked();
        void on_Board3_clicked();
        void on_Board4_clicked();
        void on_Board5_clicked();
        void on_Board6_clicked();
        void on_Board7_clicked();
        void on_Board8_clicked();
        void on_Board9_clicked();
//Buttons for user interaction with Available_Boards section on RIGHT.
        void on_board1_clicked();
        void on_board2_clicked();
        void on_board3_clicked();
        void on_board4_clicked();
        void on_board5_clicked();
        void on_board6_clicked();
        void on_board7_clicked();
        void on_board8_clicked();
        void on_board9_clicked();

    public:
        unordered_map<int,QPushButton*> Pushers;// call Pushers[n-1] for PushButton_9 /*ATTENTION*/
        unordered_map<int,function<void()>> editor_buttons;//call editor_buttons[n-1] for on_PushButton_n_clicked()/*ATTENTION*/
        unordered_map<QPushButton*, ButtonState> initialStates;//for resetting buttons to initial states
        unordered_map<int, QLabel*> Main_Labels;
        unordered_map<vector<QString>*,function<void()>> board_pushers;
        unordered_map <int,QPushButton*> Available_Pushers;
};

#endif // MAINWINDOW_H
